I have archived the project into the attached .ZIP file. The gerber 
files are in RS-274-X format - embedded apertures (no human 
editing required). I have also created DXF and HPGL files of the 
assy & fab info. with the assy simply an outline with parts. There is 
a gerber file of the fab drawing included so your vendor will have no 
problem getting that data from you. Drill files for an Excellon 
machine are included, as well as both imperial & metric auto-insert 
files. The PCB Footprint value for J203 has changed and this has 
been updated on the schematic (also included). A complete set of 
Winplots is included, as is a complete P-CAD database + all 
support files needed for someone else to be able to use it.

All the revisions and corrections have been incorporated into the 
finished database. If there is anything more that needs to be done 
to it do not hesitate to contact me. 

Best Wishes for the new year!

Ken Lunders
