The noise injecting booster is based on a Lenz LV100 Booster.
The schematics in BOOST1.GIF and BOOST2.GIF show the changes
made to the basic LV100 to make it a noise injecting booster.